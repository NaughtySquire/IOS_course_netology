import UIKit

var greeting = "Дароу!"
